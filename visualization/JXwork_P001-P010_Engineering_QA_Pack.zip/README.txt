JXwork P001-P010 工程问题整合包

1. 完整解压 ZIP，不要在压缩包预览界面直接打开 Excel。
2. 打开 JXwork_P001-P010_Engineering_QA.xlsx；十个 Sheet 一一对应 P001 至 P010。
3. D 列超链接指向同级 resources/ 中的本地 HTML 资料；不要移动或改名 resources 文件夹。
4. 作者论文与源码可先打开本地入口页，在线原始网站仍需要联网。
5. Excel/WPS 对本地文件链接可能有安全提示；这是软件的正常安全机制。
6. 所有问题表数据来源于已整理、压缩精修的 P001-P010 GitHub 工程速查 CSV。
